Config = {}
Config.Appearance = "illenium-appearance" -- "esx_skin" or "illenium-appearance"
Config.Title = "TRD PED MENU"
Config.Command = "ped"
Config.playersinfo= {
    ["license:1234"] = {   ---player 1
        peds = { "a_m_y_smartcaspat_01", "g_m_y_famca_01"}
    },
    ["license:1234"] = { ----player 2
        peds = { "a_m_y_smartcaspat_01", "g_m_y_famca_01"}
    }
----can add more
}