fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'trd'
description 'Ped Change Script for FiveM'
version '1.0.0'
shared_script 'config.lua'
client_script {
    'client.lua'
}
server_script {
    'config.lua',
    'server.lua'
}

dependency 'es_extended'
shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}
escrow_ignore {
    'config.lua'
}
dependency '/assetpacks'